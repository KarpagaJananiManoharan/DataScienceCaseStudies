/*
				ASSIGNMENT PART 1
                
*/
-- Create a new schema named 'Assignment'
CREATE DATABASE IF NOT EXISTS Assignment;
-- I had imported the CSV files in MySQL using the wizard, naming the tables as the name of the stocks as follows:
-- bajaj auto, eicher motors, hero motorcorp, infosys, tcs, tvs motors
-- -------------------------------------------------------------------------------------------------------------
-- 1. Create a new table named 'bajaj1' containing the date, close price, 20 Day MA and 50 Day MA.
-- (This has to be done for all 6 stocks)

-- Creating Bajaj1
DROP TABLE  IF EXISTS bajaj1;
CREATE TABLE bajaj1 AS
(
WITH CTE_MA (MarketDate, ClosingPrice, RowNumber, MA20, MA50)
AS
(
SELECT str_to_date(date,"%d-%M-%Y") as MarketDate,
       `Close Price` as ClosingPrice,
       ROW_NUMBER() OVER (ORDER BY Date ASC) RowNumber,
       AVG(`Close Price`) OVER (ORDER BY Date ASC ROWS 19 PRECEDING) AS MA20,
       AVG(`Close Price`) OVER (ORDER BY Date ASC ROWS 49 PRECEDING) AS MA50
FROM   `bajaj auto`
)
 
SELECT MarketDate,
       ClosingPrice,
       case when RowNumber > 19 then ROUND(MA20,2) ELSE 'HOLD' end as MA20,
       case when RowNumber > 49 then ROUND(MA50,2) ELSE 'HOLD' end as MA50   
FROM   CTE_MA
ORDER BY MarketDate
);
-- -------------------------------------------------------------------------------------------------
-- Creating EicherMotors1
DROP TABLE  IF EXISTS EicherMotors1;
CREATE TABLE EicherMotors1 AS
(
WITH CTE_MA2 (MarketDate, ClosingPrice, RowNumber, MA20, MA50)
AS
(
SELECT str_to_date(date,"%d-%M-%Y") as MarketDate,
       `Close Price` as ClosingPrice,
       ROW_NUMBER() OVER (ORDER BY Date ASC) RowNumber,
       AVG(`Close Price`) OVER (ORDER BY Date ASC ROWS 19 PRECEDING) AS MA20,
       AVG(`Close Price`) OVER (ORDER BY Date ASC ROWS 49 PRECEDING) AS MA50
FROM   `eicher motors`
)
 
SELECT MarketDate,
       ClosingPrice,
       case when RowNumber > 19 then ROUND(MA20,2) ELSE 'HOLD' end as MA20,
       case when RowNumber > 49 then ROUND(MA50,2) ELSE 'HOLD' end as MA50   
FROM   CTE_MA2
ORDER BY MarketDate
);
-- -------------------------------------------------------------------------------------------------
-- Creating HeroMotocorp1
DROP TABLE  IF EXISTS HeroMotocorp1;
CREATE TABLE HeroMotocorp1 AS
(

WITH CTE_MA3 (MarketDate, ClosingPrice, RowNumber, MA20, MA50)
AS
(
SELECT str_to_date(date,"%d-%M-%Y") as MarketDate,
       `Close Price` as ClosingPrice,
       ROW_NUMBER() OVER (ORDER BY Date ASC) RowNumber,
       AVG(`Close Price`) OVER (ORDER BY Date ASC ROWS 19 PRECEDING) AS MA20,
       AVG(`Close Price`) OVER (ORDER BY Date ASC ROWS 49 PRECEDING) AS MA50
FROM   `hero motocorp`
)
 
SELECT MarketDate,
       ClosingPrice,
       case when RowNumber > 19 then ROUND(MA20,2) ELSE 'HOLD' end as MA20,
       case when RowNumber > 49 then ROUND(MA50,2) ELSE 'HOLD' end as MA50   
FROM   CTE_MA3
ORDER BY MarketDate
);
-- ------------------------------------------------------------------------------------------------
-- Creating infosys1
DROP TABLE  IF EXISTS infosys1;
CREATE TABLE infosys1 AS
(
WITH CTE_MA4 (MarketDate, ClosingPrice, RowNumber, MA20, MA50)
AS
(
SELECT str_to_date(date,"%d-%M-%Y") as MarketDate,
       `Close Price` as ClosingPrice,
       ROW_NUMBER() OVER (ORDER BY Date ASC) RowNumber,
       AVG(`Close Price`) OVER (ORDER BY Date ASC ROWS 19 PRECEDING) AS MA20,
       AVG(`Close Price`) OVER (ORDER BY Date ASC ROWS 49 PRECEDING) AS MA50
FROM   `infosys`
)
 
SELECT MarketDate,
       ClosingPrice,
       case when RowNumber > 19 then ROUND(MA20,2) ELSE 'HOLD' end as MA20,
       case when RowNumber > 49 then ROUND(MA50,2) ELSE 'HOLD' end as MA50   
FROM   CTE_MA4
ORDER BY MarketDate
);
-- -------------------------------------------------------------------------------------------------
-- Creating TCS1
DROP TABLE  IF EXISTS tcs1;
CREATE TABLE tcs1 AS
(
WITH CTE_MA5 (MarketDate, ClosingPrice, RowNumber, MA20, MA50)
AS
(
SELECT str_to_date(date,"%d-%M-%Y") as MarketDate,
       `Close Price` as ClosingPrice,
       ROW_NUMBER() OVER (ORDER BY Date ASC) RowNumber,
       AVG(`Close Price`) OVER (ORDER BY Date ASC ROWS 19 PRECEDING) AS MA20,
       AVG(`Close Price`) OVER (ORDER BY Date ASC ROWS 49 PRECEDING) AS MA50
FROM   tcs
)
 
SELECT MarketDate,
       ClosingPrice,
       case when RowNumber > 19 then ROUND(MA20,2) ELSE 'HOLD' end as MA20,
       case when RowNumber > 49 then ROUND(MA50,2) ELSE 'HOLD' end as MA50   
FROM   CTE_MA5
ORDER BY MarketDate
);
-- -------------------------------------------------------------------------------------------------
-- Creating TVSMotors1
DROP TABLE  IF EXISTS TVSMotors1;
CREATE TABLE TVSMotors1 AS
(
WITH CTE_MA6 (MarketDate, ClosingPrice, RowNumber, MA20, MA50)
AS
(
SELECT str_to_date(date,"%d-%M-%Y") as MarketDate,
       `Close Price` as ClosingPrice,
       ROW_NUMBER() OVER (ORDER BY Date ASC) RowNumber,
       AVG(`Close Price`) OVER (ORDER BY Date ASC ROWS 19 PRECEDING) AS MA20,
       AVG(`Close Price`) OVER (ORDER BY Date ASC ROWS 49 PRECEDING) AS MA50
FROM   `TVS Motors`
)
 
SELECT MarketDate,
       ClosingPrice,
       case when RowNumber > 19 then ROUND(MA20,2) ELSE 'HOLD' end as MA20,
       case when RowNumber > 49 then ROUND(MA50,2) ELSE 'HOLD' end as MA50   
FROM   CTE_MA6
ORDER BY MarketDate
);
-- ----------------------------------------------------------------------------------------------
-- 2. Create a master table containing the date and close price of all the six stocks. 
-- (Column header for the price is the name of the stock)
DROP TABLE IF EXISTS MasterTable;
-- Creating Master Table
CREATE TABLE MasterTable AS
 select bajaj1.MarketDate as Date ,bajaj1.ClosingPrice as Bajaj, tcs1.ClosingPrice as TCS,
 tvsmotors1.ClosingPrice as TVS, infosys1.ClosingPrice as Infosys,eichermotors1.ClosingPrice as Eicher, 
 heromotocorp1.ClosingPrice as Hero FROM bajaj1
 INNER JOIN eichermotors1 USING(MarketDate)
 INNER JOIN heromotocorp1 USING(MarketDate)
 INNER JOIN infosys1 USING(MarketDate)
 INNER JOIN tcs1 USING(MarketDate)
 INNER JOIN tvsmotors1 USING(MarketDate);
 
-- Now we check the records in the master table
select * from MasterTable;
-- ----------------------------------------------------------------------------------------------
-- Use the table created in Part(1) to generate buy and sell signal. Store this in another table named 'bajaj2'. Perform this operation for all stocks.
DROP TABLE  IF EXISTS bajaj2;
-- Creating Bajaj2
CREATE TABLE bajaj2 AS

WITH CTE_signal1 (MarketDate, ClosingPrice, RowNumber, MA20, MA50)
AS
(
SELECT MarketDate,
       ClosingPrice,
       ROW_NUMBER() OVER (ORDER BY MarketDate ASC) RowNumber, MA20,MA50
FROM   bajaj1
)
SELECT MarketDate,
       ClosingPrice,
       CASE
          WHEN RowNumber > 49 AND MA20 > MA50 THEN 'SELL'
          WHEN RowNumber > 49 AND MA20 < MA50 THEN 'BUY'
          WHEN (RowNumber > 49 AND MA20 = MA50) OR MA20 IS NULL OR MA50 IS NULL THEN 'HOLD'
          ELSE 'HOLD'
       END as BuySellSignal
FROM   CTE_signal1
ORDER BY MarketDate;
select * from bajaj2;
-- -----------------------------------------------------------------------------------------
DROP TABLE  IF EXISTS eicher2;
-- Creating eicher2
CREATE TABLE eicher2 AS

WITH CTE_signal2 (MarketDate, ClosingPrice, RowNumber, MA20, MA50)
AS
(
SELECT MarketDate,
       ClosingPrice,
       ROW_NUMBER() OVER (ORDER BY MarketDate ASC) RowNumber, MA20,MA50
FROM   eichermotors1
)
SELECT MarketDate,
       ClosingPrice,
       CASE
          WHEN RowNumber > 49 AND MA20 > MA50 THEN 'SELL'
          WHEN RowNumber > 49 AND MA20 < MA50 THEN 'BUY'
          WHEN (RowNumber > 49 AND MA20 = MA50) OR MA20 IS NULL OR MA50 IS NULL THEN 'HOLD'
          ELSE 'HOLD'
       END as BuySellSignal
FROM   CTE_signal2
ORDER BY MarketDate;
select * from eicher2;
-- -----------------------------------------------------------------------------------------
DROP TABLE  IF EXISTS hero2;
-- Creating hero2
CREATE TABLE hero2 AS

WITH CTE_signal3 (MarketDate, ClosingPrice, RowNumber, MA20, MA50)
AS
(
SELECT MarketDate,
       ClosingPrice,
       ROW_NUMBER() OVER (ORDER BY MarketDate ASC) RowNumber, MA20,MA50
FROM   eichermotors1
)
SELECT MarketDate,
       ClosingPrice,
       CASE
          WHEN RowNumber > 49 AND MA20 > MA50 THEN 'SELL'
          WHEN RowNumber > 49 AND MA20 < MA50 THEN 'BUY'
          WHEN (RowNumber > 49 AND MA20 = MA50) OR MA20 IS NULL OR MA50 IS NULL THEN 'HOLD'
          ELSE 'HOLD'
       END as BuySellSignal
FROM   CTE_signal3
ORDER BY MarketDate;
select * from eicher2;
-- -----------------------------------------------------------------------------------------
DROP TABLE  IF EXISTS hero2;
-- Creating hero2
CREATE TABLE hero2 AS

WITH CTE_signal3 (MarketDate, ClosingPrice, RowNumber, MA20, MA50)
AS
(
SELECT MarketDate,
       ClosingPrice,
       ROW_NUMBER() OVER (ORDER BY MarketDate ASC) RowNumber, MA20,MA50
FROM   heromotocorp1
)
SELECT MarketDate,
       ClosingPrice,
       CASE
          WHEN RowNumber > 49 AND MA20 > MA50 THEN 'SELL'
          WHEN RowNumber > 49 AND MA20 < MA50 THEN 'BUY'
          WHEN (RowNumber > 49 AND MA20 = MA50) OR MA20 IS NULL OR MA50 IS NULL THEN 'HOLD'
          ELSE 'HOLD'
       END as BuySellSignal
FROM   CTE_signal3
ORDER BY MarketDate;
select * from hero2;
-- -----------------------------------------------------------------------------------------
DROP TABLE  IF EXISTS infosys2;
-- Creating infosys2
CREATE TABLE infosys2 AS

WITH CTE_signal4 (MarketDate, ClosingPrice, RowNumber, MA20, MA50)
AS
(
SELECT MarketDate,
       ClosingPrice,
       ROW_NUMBER() OVER (ORDER BY MarketDate ASC) RowNumber, MA20,MA50
FROM   infosys1
)
SELECT MarketDate,
       ClosingPrice,
       CASE
          WHEN RowNumber > 49 AND MA20 > MA50 THEN 'SELL'
          WHEN RowNumber > 49 AND MA20 < MA50 THEN 'BUY'
          WHEN (RowNumber > 49 AND MA20 = MA50) OR MA20 IS NULL OR MA50 IS NULL THEN 'HOLD'
          ELSE 'HOLD'
       END as BuySellSignal
FROM   CTE_signal4
ORDER BY MarketDate;
select * from infosys2;
-- -----------------------------------------------------------------------------------------
DROP TABLE  IF EXISTS tcs2;
-- Creating TCS2
CREATE TABLE tcs2 AS

WITH CTE_signal5 (MarketDate, ClosingPrice, RowNumber, MA20, MA50)
AS
(
SELECT MarketDate,
       ClosingPrice,
       ROW_NUMBER() OVER (ORDER BY MarketDate ASC) RowNumber, MA20,MA50
FROM   tcs1
)
SELECT MarketDate,
       ClosingPrice,
       CASE
          WHEN RowNumber > 49 AND MA20 > MA50 THEN 'SELL'
          WHEN RowNumber > 49 AND MA20 < MA50 THEN 'BUY'
          WHEN (RowNumber > 49 AND MA20 = MA50) OR MA20 IS NULL OR MA50 IS NULL THEN 'HOLD'
          ELSE 'HOLD'
       END as BuySellSignal
FROM   CTE_signal5
ORDER BY MarketDate;
select * from tcs2;
-- -----------------------------------------------------------------------------------------
DROP TABLE  IF EXISTS tvs2;
-- Creating TVS2
CREATE TABLE tvs2 AS

WITH CTE_signal6 (MarketDate, ClosingPrice, RowNumber, MA20, MA50)
AS
(
SELECT MarketDate,
       ClosingPrice,
       ROW_NUMBER() OVER (ORDER BY MarketDate ASC) RowNumber, MA20,MA50
FROM   tvsmotors1
)
SELECT MarketDate,
       ClosingPrice,
       CASE
          WHEN RowNumber > 49 AND MA20 > MA50 THEN 'SELL'
          WHEN RowNumber > 49 AND MA20 < MA50 THEN 'BUY'
          WHEN (RowNumber > 49 AND MA20 = MA50) OR MA20 IS NULL OR MA50 IS NULL THEN 'HOLD'
          ELSE 'HOLD'
       END as BuySellSignal
FROM   CTE_signal6
ORDER BY MarketDate;
select * from tvs2;
-- -----------------------------------------------------------------------------------------
-- 4. Create a User defined function, that takes the date as input and returns the signal for that particular day (Buy/Sell/Hold) for the Bajaj stock.
DROP FUNCTION IF EXISTS fn_getsignal;
DELIMITER //
-- Creating User Defined Function fn_getsignal to get the signal
CREATE FUNCTION fn_getsignal
   (inputdate date) RETURNS text DETERMINISTIC	
BEGIN
DECLARE bssignal text;

 select buysellsignal into bssignal from bajaj2 
  where marketdate=inputdate;
  
RETURN bssignal;

END
//	
DELIMITER ;

-- Now call the function to get the signal for a specific date from bajaj table
select *,fn_getsignal (marketdate) from bajaj2 ;

-- -------------------------------------------------------------------------------------------------